export const environment = {
  production: true,
  apiUrl: "https://api.ratl.ir",
  Version: "1",
};
